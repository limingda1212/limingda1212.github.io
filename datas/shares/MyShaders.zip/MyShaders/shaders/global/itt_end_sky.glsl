// ============================================
// iterationT 3.2.0 末地天空效果移植 Mellow 3.1.1
// 包含：黑洞、吸积盘、木星、木星环、星星
// ============================================

#ifndef ITT_END_SKY_INCLUDED
#define ITT_END_SKY_INCLUDED

// 数学常量
#ifndef PI
// 降低精度优化计算 #define PI 3.14159265358979323846
#define PI 3.1415926
#endif

#ifndef TAU
// 降低精度优化计算 #define TAU 6.28318530717958647692
#define TAU 6.2831853
#endif

// 时间因子和行星阴影
#ifdef END_MANUAL_PLANET_CYCLE
const float timeFactor = fract(END_MANUAL_PLANET_ANGLE / 360.0 + 0.282) * TAU;
#else
float timeFactor = fract(frameTimeCounter * ((1.0 / 60.0) / END_PLANET_CYCLE) + 0.282) * TAU;
#endif

float planetShadow = smoothstep(0.62, 0.35, timeFactor) + smoothstep(1.6, 1.87, timeFactor);


// ============================================
// 辅助函数
// ============================================

vec3 H(vec3 albedo, float a){
    vec3 R = sqrt(vec3(1.0) - albedo);
    vec3 r = (1.0 - R) / (1.0 + R);
    vec3 H = r + (0.5 - r * a) * log((1.0 + a) / a);
    H *= albedo * a;
    return 1.0 / (1.0 - H);
}

vec3 ppss(vec3 albedo, vec3 normal, vec3 eyeDir, vec3 lightDir, float s){
    float NdotL = dot(normal, lightDir);
    float NdotV = dot(normal, eyeDir);
    albedo *= pow(clamp(NdotL, 0.0, 1.0), 2.2); // curve ≈ gamma 2.2
    vec3 color = albedo * H(albedo, NdotL) * H(albedo, NdotV) / (4.0 * PI * (NdotL + NdotV));
    return clamp(color, 0.0, 1.0);
}

float Disc(float a, float s, float h){
    float disc = pow(clamp((a - (1.0 - s)) * h, 0.0, 1.0), 2.2);
    return disc * disc;
}

mat3 RotateMatrix(float x, float y, float z){
    mat3 matx = mat3(1.0, 0.0, 0.0,
                     0.0, cos(x), sin(x),
                     0.0, -sin(x), cos(x));
    mat3 maty = mat3(cos(y), 0.0, -sin(y),
                     0.0, 1.0, 0.0,
                     sin(y), 0.0, cos(y));
    mat3 matz = mat3(cos(z), sin(z), 0.0,
                     -sin(z), cos(z), 0.0,
                     0.0, 0.0, 1.0);
    return maty * matx * matz;
}

void WarpSpace(inout vec3 eyevec, inout vec3 raypos){
    vec3 origin = vec3(0.0, 0.0, 0.0);
    float singularityDist = distance(raypos, origin);
    float warpFactor = 1.0 / (singularityDist * singularityDist + 0.000001);
    vec3 singularityVector = normalize(origin - raypos);

    // ===== 引力强度系数 =====
    // 想让中间黑圈更大：改大，比如 0.08、0.1
    // 想让中间黑圈更小：改小，比如 0.04、0.03
    float warpAmount = 0.07;
    eyevec = normalize(eyevec + singularityVector * warpFactor * warpAmount);
}

float Calculate3DNoise(vec3 position){
    vec3 p = floor(position);
    vec3 b = pow(fract(position), vec3(2.2)); // curve ≈ gamma 2.2
    vec2 uv = 17.0 * p.z + p.xy + b.xy;
    vec2 rg = textureLod(noisetex, (uv + 0.5) / 64.0, 0.0).zx;
    return mix(rg.x, rg.y, b.z);
}

float CalculateCloudFBM(vec3 position, vec3 shift){
    const int octaves = 4;
    const float octAlpha = 0.87;
    const float octScale = 2.5;
    const float octShift = (octAlpha / octScale) / octaves;
    float accum = 0.0;
    float alpha = 0.5;
    for (int i = 0; i < octaves; i++) {
        accum += alpha * Calculate3DNoise(position);
        position = (position + shift) * octScale;
        alpha *= octAlpha;
    }
    return accum + octShift;
}

float CalculateCloudFBM_LQ(vec3 position, vec3 shift){
    const int octaves = 3;
    const float octAlpha = 0.9;
    const float octScale = 2.0;
    const float octShift = (octAlpha / octScale) / octaves;
    float accum = 0.0;
    float alpha = 0.5;
    for (int i = 0; i < octaves; i++) {
        accum += alpha * Calculate3DNoise(position);
        position = (position + shift) * octScale;
        alpha *= octAlpha;
    }
    return accum + octShift;
}

float pcurve(float x){
    float x2 = x * x;
    return 12.207 * x2 * x2 * (1.0 - x);
}

// 黑体辐射颜色
vec3 Blackbody(float temperature){
    float t = temperature / 1000.0;
    vec3 color;
    if (t < 6.5){
        color.r = 1.0;

        // 降低精度优化计算 color.g = 0.3900815787690196 * t - 0.089879596752 * t * log(t) - 0.55;
        
        color.g = 0.39008 * t - 0.08987 * t * log(t) - 0.55;
    } else {

        // 降低精度优化计算 color.r = 1.292936186062745 * pow(t - 6.0, -0.1332047592);
        // 降低精度优化计算 color.g = 1.129890860895294 * pow(t - 6.0, -0.0755148492);

        color.r = 1.29293 * pow(t - 6.0, -0.13320);
        color.g = 1.12989 * pow(t - 6.0, -0.07551);
    }
    if (t >= 6.6){
        color.b = 1.0;
    } else if (t <= 1.0){
        color.b = 0.0;
    } else {
        // 降低精度优化计算 color.b = 0.543206789110196 * t + 0.089879596752 * t * log(t - 1.0) - 1.05;

        color.b = 0.54320 * t + 0.08987 * t * log(t - 1.0) - 1.05;
    }
    return clamp(color, 0.0, 1.0);
}

// Mie 相位函数
float MiePhaseFunction(float g, float cos){
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * PI * pow(1.0 + g2 - 2.0 * g * cos, 1.5));
}

// 射线球相交
vec2 RaySphereIntersection(vec3 ro, vec3 rd, float r){
    float b = dot(ro, rd);
    float c = dot(ro, ro) - r * r;
    float h = b * b - c;
    if (h < 0.0) return vec2(-1.0);
    h = sqrt(h);
    return vec2(-b - h, -b + h);
}

// 射线平面相交
vec3 RayPlaneIntersection(vec3 ro, vec3 rd, vec3 n){
    float t = -dot(ro, n) / dot(rd, n);
    return ro + rd * t;
}

// 交错梯度噪声
float InterleavedGradientNoise(vec2 pos){
    vec3 m = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(m.z * fract(dot(pos, m.xy)));
}

// 蓝噪声时间采样（简化版）
float BlueNoiseTemporal(){
    return InterleavedGradientNoise(texcoord * 1000.0 + frameTimeCounter);
}


// ============================================
// 星空
// ============================================

vec3 CalculateStars(vec3 worldDir){
    float angleY = frameTimeCounter * 0.001;
    mat3 eyeRoataionMatrixY = mat3(cos(angleY), 0, sin(angleY), 0, 1, 0, -sin(angleY), 0, cos(angleY));
    worldDir = eyeRoataionMatrixY * worldDir;

    #if STAR_TYPE == 2
        // 明亮模式：星星更大、更亮、更多
        const float scale = 256.0;
        const float coverage = 0.012;
        const float maxLuminance = 0.12;
        const float starRadiusSq = 0.35;
    #else
        // 普通模式：默认参数
        const float scale = 384.0;
        const float coverage = 0.007;
        const float maxLuminance = 0.04;
        const float starRadiusSq = 0.25;
    #endif

    const float minTemperature = 4000.0;
    const float maxTemperature = 8000.0;

    vec3 p = worldDir * scale;
    ivec3 i = ivec3(floor(p));
    vec3 f = p - i;
    float r = dot(f - 0.5, f - 0.5);

    vec3 i3 = fract(i * vec3(443.897, 441.423, 437.195));
    i3 += dot(i3, i3.yzx + 19.19);
    vec2 hash = fract((i3.xx + i3.yz) * i3.zy);
    hash.y = 2.0 * hash.y - 4.0 * hash.y * hash.y + 3.0 * hash.y * hash.y * hash.y;

    float c = clamp((hash.x - (1.0 - coverage)) / coverage, 0.0, 1.0);
    return (maxLuminance * clamp((starRadiusSq - r) / starRadiusSq, 0.0, 1.0) * c * c) * Blackbody(mix(minTemperature, maxTemperature, hash.y));
}


// ============================================
// 黑洞 + 吸积盘 + 星星
// ============================================

void BlackHole_AccretionDisc_Stars(inout vec3 color, in vec3 rayDir, in vec3 lightDir){
    // ***** 黑洞光线步进步数,降低可以减少计算量，但代价是吸积盘的细节会稍微减少一点 *****
    // const float steps = 50.0;
    const float steps = 25.0;

    const float rSteps = 1.0 / steps;
    const float stepLength = 0.2;

    // ===== 黑洞计算大小 =====
    // discRadius：吸积盘的中心半径，增大它吸积盘整体变大
    // discWidth：吸积盘的宽度，增大它吸积盘变宽变粗
    
    const float discRadius = 2.25;
    // const float discRadius = 3.0;
    const float discWidth = 3.5;
    // const float discWidth = 5.0;

    const float discInner = discRadius - discWidth * 0.5;
    const float discOuter = discRadius + discWidth * 0.5;

    #if TAA_MODE > 0
        float noise = BlueNoiseTemporal();
    #else
        float noise = InterleavedGradientNoise(texcoord * 1000.0);
    #endif

    // ===== 黑洞视觉大小 =====
    // 想让黑洞变大：改小，比如改成 5.0 或 4.0（离得越近看起来越大）
    // 想让黑洞变小：改大，比如改成 12.0 或 15.0
    // 整体比例不会变
    vec3 eye = -lightDir * 6.0;

    vec3 rayPos = eye + rayDir * 3.0;

    mat3 rotation = RotateMatrix(0.1, 0.0, -0.35);

    vec3 result = vec3(0.0);
    float transmittance = 1.0;

    rayPos += rayDir * stepLength * noise;

    for(int i = 0; i < steps; i++){
        if(transmittance < 0.0001) break;

        WarpSpace(rayDir, rayPos);
        rayPos += rayDir * stepLength;

        {
            vec3 discPos = rotation * rayPos;

            float r = length(discPos);
            float p = atan(-discPos.z, discPos.x); // 修复 atan2 → atan
            float h = discPos.y;

            float radialGradient = 1.0 - clamp((r - discInner) / discWidth * 0.5, 0.0, 1.0);
            float dist = abs(h);

            float discThickness = 0.1 * radialGradient;

            float fr = abs(r - discInner) + 0.4;
            fr = fr * fr;
            float fade = fr * fr * 0.04;
            float bloomFactor = 1.0 / (h * h * 40.0 + fade + 0.00002);
            bloomFactor *= clamp(2.0 - abs(dist) / discThickness, 0.0, 1.0);
            bloomFactor = bloomFactor * bloomFactor;

            float dr = pcurve(radialGradient);

            // ===== 吸积盘密度 =====
            // density = clamp(density * 0.8, 0.0, 1.0);
            // 增大（比如 0.8 改成 1.0）：吸积盘更厚、更亮、更不透明
            // 减小（比如 0.8 改成 0.5）：吸积盘更薄、更暗、更透明
            float density = dr;

            density *= clamp(1.0 - abs(dist) / discThickness, 0.0, 1.0);
            density = clamp(density * 0.8, 0.0, 1.0);
            density = clamp(density + bloomFactor * 0.1, 0.0, 1.0);

            if (density > 0.0001){
                #ifdef ACCRETIONDISC_DETAIL_ALONG_LONGTITUDE
                    vec3 discCoord = vec3(r, p * (1.0 - radialGradient * 0.5), h * 0.1) * 3.5;
                    float fbm = CalculateCloudFBM(discCoord, frameTimeCounter * vec3(0.1, 0.07, 0.0));
                #else
                    vec3 discCoord = vec3(r, 0.0, h * 0.1) * 3.5;
                    float fbm = CalculateCloudFBM(discCoord, frameTimeCounter * vec3(0.03, 0.05, 0.0));
                #endif
                fbm = fbm * fbm;
                fbm = fbm * fbm;

                density *= fbm * dr;

                float gr = 1.0 - radialGradient;
                gr = gr * gr;

                // ===== 吸积盘辉光强度 =====
                // float glowStrength = 1.0 / (gr * gr * 400.0 + 0.002);
                // 减小（比如 400.0 改成 200.0）：辉光更强，吸积盘更亮
                // 增大（比如 400.0 改成 600.0）：辉光更弱，吸积盘更暗
                float glowStrength = 1.0 / (gr * gr * 400.0 + 0.002);
                
                // ===== 黑洞颜色 =====
                // 增大让颜色偏黄白色/暖色
                // 减小让颜色偏蓝紫色/冷色
                vec3 glow = Blackbody(6500.0 + glowStrength * 30.0) * glowStrength;
                
                glow *= vec3(1.2, 1.0, 0.75);

                #ifdef ACCRETIONDISC_DOPPLER_EFFECT
                    glow *= sin(p - 1.07) * 0.75 + 1.0;
                #endif

                float stepTransmittance = exp2(-density * 7.0);
                float integral = 1.0 - stepTransmittance;
                transmittance *= stepTransmittance;

                result += integral * transmittance * glow;
            }

            vec2 t = vec2(1.0, 0.01);
            float torusDist = length(length(discPos + vec3(0.0, -0.05, 0.0)) - t);
            float bloomDisc = 1.0 / (pow(torusDist, 3.5) + 0.001);
            vec3 col = Blackbody(5700.0);
            bloomDisc *= step(0.5, r);

            // ===== 外环辉光亮度 =====
            // 这个 0.1 控制外环（甜甜圈形状的那个外圈）的辉光亮度
            // 增大：外环更亮
            // 减小：外环更暗
            // result += col * bloomDisc * 0.1 * transmittance;
            result += col * bloomDisc * 0.3 * transmittance;
        }
    }

    // ===== 整体亮度倍数 =====
    // 越大越亮
    // result *= rSteps * 2.5;
    result *= rSteps * 3.0;

    #if STAR_TYPE > 0
        color += CalculateStars(rayDir);
    #endif

    color *= transmittance;

    color += result;
}


// ============================================
// 木星 + 木星环
// ============================================

void PlanetEnd2(inout vec3 color, in vec3 eye, in vec3 rayDir, in vec3 lightDir){
    const float Rground = 20e6;
    const float Ratmo = 20.1e6;
    eye.y += Rground;
    eye.y += 15e6;

    float VdotL = dot(lightDir, rayDir); // worldShadowVector → lightDir
    float mie = MiePhaseFunction(0.8, VdotL);

    float angleX = -1.57079633 + (0.2 * sin(timeFactor + 3.0) - 0.1);
    float angleY = timeFactor;

    mat3 eyeRoataionMatrixX = mat3(1, 0, 0, 0, cos(angleX), -sin(angleX), 0, sin(angleX), cos(angleX));
    mat3 eyeRoataionMatrixY = mat3(cos(angleY), 0, sin(angleY), 0, 1, 0, -sin(angleY), 0, cos(angleY));
    mat3 eyeRoataionMatrix = eyeRoataionMatrixX * eyeRoataionMatrixY;

    float ringAngle = 0.008 * sin(timeFactor + 4.6);

    mat3 ringRoataionMatrix = mat3(1.0, 0.0, 0.0,
                                   0.0, cos(ringAngle), sin(ringAngle),
                                   0.0, -sin(ringAngle), cos(ringAngle));
    mat3 ringRoataionMatrixInverse = transpose(ringRoataionMatrix);

    rayDir = eyeRoataionMatrix * rayDir;
    lightDir = eyeRoataionMatrix * lightDir;

    vec3 rayDirRing = ringRoataionMatrix * rayDir;
    vec3 lightDirRing = ringRoataionMatrix * lightDir;

    vec3 ringOrigin = vec3(0.0, cos(ringAngle), sin(ringAngle)) * (eye.y / Rground);
    vec2 ringRadius = vec2(1.6, 2.6);

    vec3 surface = vec3(0.0);
    float LdotR = dot(rayDir, -lightDir);

    vec2 groundIntersection = RaySphereIntersection(eye, rayDir, Rground);
    vec2 topAtmoIntersection = RaySphereIntersection(eye, rayDir, Ratmo);

    vec3 surfacePos = rayDir * groundIntersection.x;
    vec3 surfaceNormal = normalize(surfacePos + vec3(0.0, eye.y, 0.0));

    if (groundIntersection.y > 0.0){
        color *= 0.0;

        vec3 surfaceAlbedo = vec3(0.98, 0.87, 0.55);

        surface = ppss(surfaceAlbedo, surfaceNormal, -rayDir, lightDir, 1.0);

        vec3 origin = ringOrigin + surfacePos / Rground;
        vec3 rayPos = RayPlaneIntersection(origin, lightDirRing, vec3(0.0, 0.0, 1.0));
        float rayRadius = length(rayPos);

        if (rayRadius > ringRadius.x && rayRadius < ringRadius.y && dot(rayPos - origin, lightDirRing) > 0.0){
            const float octAlpha = 0.5;
            float octScale = 4.0;
            float octShift = (octAlpha / octScale) / 5;

            float accum = 0.0;
            float alpha = 0.5;
            float shift = 0.0;

            float position = rayRadius * 0.5 + 0.69;
            position += shift;

            for (int i = 0; i < 5; i++){
                accum += alpha * textureLod(noisetex, vec2(position, 0.0), 0.0).z;
                position = (position + shift) * octScale;
                alpha *= octAlpha;
            }

            surface *= exp(-pow(clamp(accum + octShift - 0.1, 0.0, 1.0) * 1.5, 3.0) * smoothstep(ringRadius.x, ringRadius.x * 1.1, rayRadius));
        }

        float UdotN = clamp(dot(ringRoataionMatrixInverse[2], surfaceNormal), 0.0, 1.0);
        float DdotN = clamp(dot(-ringRoataionMatrixInverse[2], surfaceNormal), 0.0, 1.0);
        float OLdotN = clamp(dot(ringRoataionMatrixInverse * normalize(vec3(-lightDir.xy, 0.0)), surfaceNormal), 0.0, 1.0);

        float ringLighting = Disc(UdotN, 1.2, 1.5) * (1.0 - Disc(UdotN, 3.4, 0.3));
        ringLighting += Disc(DdotN, 1.2, 1.5) * (1.0 - Disc(DdotN, 3.4, 0.3));
        ringLighting *= 1.0 - Disc(OLdotN, 0.7, 1.3);

        surface += surfaceAlbedo * (1.5e-4 + ringLighting * 0.01);
    }

    if (topAtmoIntersection.y > 0.0){
        float isGround = step(0.0, groundIntersection.y);
        float thickness = (topAtmoIntersection.y - topAtmoIntersection.x - (groundIntersection.y - groundIntersection.x) * isGround) * 1e-7;
        float topAtmoMie = mie * thickness * thickness;
        topAtmoMie *= mix(1.0, smoothstep(0.9, 0.4, dot(surfaceNormal, normalize(eye))), isGround);
        surface += topAtmoMie * vec3(0.65, 0.7, 1.0);
    }

    // ===== 表面亮度倍数 =====
    // 想更亮、更不透明：把 4.0 改大，比如 6.0、8.0
    // 想更暗：把 4.0 改小
    //  color += surface * 4.0;
    color += surface * 5.0;

    float inRing = clamp(abs(ringAngle) * 3000.0 - 0.8, 0.0, 1.0);

    float ring = 0.0;
    float transmittance = 1.0;

    if (rayDirRing.z * ringAngle < 0.0){
        vec3 origin = vec3(0.0, cos(ringAngle), sin(ringAngle)) * (eye.y / Rground);
        vec3 ringPos = RayPlaneIntersection(origin, rayDirRing, vec3(0.0, 0.0, 1.0));
        float rayRadius = length(ringPos);
        vec2 ringRadius = vec2(1.6, 2.6);

        if(rayRadius > ringRadius.x && rayRadius < ringRadius.y)
        {
            const float octAlpha = 0.5;
            float octScale = 4.0;
            float octShift = (octAlpha / octScale) / 5;

            float accum = 0.0;
            float alpha = 0.5;
            float shift = 0.0;

            float position = rayRadius * 0.5 + 0.69;
            position += shift;

            for (int i = 0; i < 5; i++) {
                accum += alpha * textureLod(noisetex, vec2(position, 0.0), 0.0).z;
                position = (position + shift) * octScale;
                alpha *= octAlpha;
            }

            ring += pow(clamp(accum + octShift - 0.1, 0.0, 1.0) * 1.5, 3.0);
            ring *= smoothstep(ringRadius.x, ringRadius.x * 1.1, rayRadius);

            if(ringPos.y < 0.0 && groundIntersection.y > 0.0){
                ring *= 0.0;
            }else{
                transmittance *= exp2(-ring * 3.0);
            }

            float d = length(cross(lightDirRing, ringPos));
            ring *= 0.98 * max(smoothstep(0.8, 1.2, d), step(0.0, dot(lightDirRing, ringPos))) + 0.02;
        }
    }

    ring = mix(planetShadow * 0.49 + 0.01, ring, inRing);
    transmittance = mix(1.0, transmittance, inRing);

    color *= transmittance;
    ring *= 1.0 + mie * 10.0 * planetShadow;

    // ===== 环的亮度倍数 =====
    // 想更亮：把 0.1 改大，比如 0.15、0.2
    // 想更暗：把 0.1 改小
    // color += ring * 0.1 * vec3(1.0, 0.85, 0.60);
    color += ring * 0.15 * vec3(1.0, 0.85, 0.60);
}


// ============================================
// 主入口函数
// ============================================

vec3 get_itt_end_sky(vec3 ViewPosN, vec3 PlayerPosN) {
    // 将视图空间方向转换为世界空间方向
    vec3 worldDir = mat3(gbufferModelViewInverse) * ViewPosN;
    vec3 worldSunDir = mat3(gbufferModelViewInverse) * sunOrMoonPosN;

    // 调整黑洞的位置，让它低一些（绕X轴向下旋转x度）
    float blackHolePitch = -1; // -x度，让黑洞低，能看到吸积盘
    mat3 blackHoleRotX = mat3(
        1.0, 0.0, 0.0,
        0.0, cos(blackHolePitch), -sin(blackHolePitch),
        0.0, sin(blackHolePitch), cos(blackHolePitch)
    );
    vec3 blackHoleDir = blackHoleRotX * worldSunDir;

    vec3 finalColor = vec3(0.0);

    // 黑洞 + 吸积盘 + 星星
    BlackHole_AccretionDisc_Stars(finalColor, worldDir, blackHoleDir);

    // 木星 + 木星环
    PlanetEnd2(finalColor, vec3(0.0), worldDir, worldSunDir);

    return finalColor;
}

#endif // ITT_END_SKY_INCLUDED
