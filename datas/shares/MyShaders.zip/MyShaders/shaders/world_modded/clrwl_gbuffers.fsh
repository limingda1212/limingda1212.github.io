#version 400 compatibility
#define DIMENSION_GENERIC

#include "/program/clrwl_gbuffers.fsh"
