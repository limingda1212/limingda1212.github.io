const _0x1972c2 = _0x1d45;

(function (_0x3d762c, _0x36b055) {
    const _0x54ac09 = _0x1d45,
        _0x4d06d1 = _0x3d762c();

    while (!![]) {
        try {
            const _0xea0c80 =
                parseInt(_0x54ac09(0x1a2)) / 0x1 * (-parseInt(_0x54ac09(0x202)) / 0x2) +
                parseInt(_0x54ac09(0x196)) / 0x3 * (parseInt(_0x54ac09(0x1ee)) / 0x4) +
                parseInt(_0x54ac09(0x1af)) / 0x5 * (-parseInt(_0x54ac09(0x150)) / 0x6) +
                -parseInt(_0x54ac09(0x1c0)) / 0x7 * (parseInt(_0x54ac09(0x194)) / 0x8) +
                parseInt(_0x54ac09(0x199)) / 0x9 +
                -parseInt(_0x54ac09(0x165)) / 0xa +
                parseInt(_0x54ac09(0x159)) / 0xb * (parseInt(_0x54ac09(0x1bd)) / 0xc);

            if (_0xea0c80 === _0x36b055) break;
            else _0x4d06d1['push'](_0x4d06d1['shift']());
        } catch (_0x422743) {
            _0x4d06d1['push'](_0x4d06d1['shift']());
        }
    }
}(_0x54d9, 0x7af42));

let students = [],
    lastSelected = null,
    isSelecting = ![],
    audioContext = null,
    rollingSound = null,
    stopSound = null,
    isSeatMode = !![],
    currentRows = 0x8,
    currentCols = 0x8,
    seatStates = [],
    randomDuration = 0x3,
    randomCount = 0x1,
    studentStates = {},
    selectionMode = 'repeat',
    selectedStudents = new Set(),
    keyboardTriggerEnabled = !![],
    rosterData = {
        'students': []
    };

const DEFAULT_ROSTER_TEMPLATE = _0x1972c2(0x151);

let classData = {
    'classes': {
        '33班': DEFAULT_ROSTER_TEMPLATE[_0x1972c2(0x1b1)]('\x0a')
    },
    'currentClass': '33班'
};

function initRosterData() {
    const _0x35f514 = _0x1972c2,
        _0x7ac5d = localStorage['getItem'](_0x35f514(0x1c9));

    _0x7ac5d
        ? rosterData = JSON[_0x35f514(0x1f8)](_0x7ac5d)
        : (
            rosterData = {
                'template': DEFAULT_ROSTER_TEMPLATE,
                'students': DEFAULT_ROSTER_TEMPLATE[_0x35f514(0x1b1)]('\x0a')[_0x35f514(0x1b5)](
                    _0x19ec80 => _0x19ec80[_0x35f514(0x1b1)]('#')[0x0]['trim']()
                )[_0x35f514(0x155)](
                    _0x458063 => _0x458063['length'] > 0x0
                )
            },
            localStorage[_0x35f514(0x1a6)]('rosterData', JSON['stringify'](rosterData))
        );
}

function initClassData() {
    const _0x22eafc = _0x1972c2,
        _0x5a0d6a = localStorage['getItem'](_0x22eafc(0x1f5));

    _0x5a0d6a
        ? classData = JSON['parse'](_0x5a0d6a)
        : (
            classData = {
                'classes': {
                    '33班': DEFAULT_ROSTER_TEMPLATE['split']('\x0a')
                },
                'currentClass': '33班'
            },
            saveClassData()
        );

    updateClassSelector();
}

document[_0x1972c2(0x1d2)](_0x1972c2(0x1fe), function () {
    const _0x4fa99e = _0x1972c2,
        _0xc7c58a = localStorage[_0x4fa99e(0x152)](_0x4fa99e(0x1c4));

    isSeatMode = _0xc7c58a === null ? !![] : _0xc7c58a === 'true';

    const _0x549358 = localStorage['getItem'](_0x4fa99e(0x1dc));
    _0x549358 && (students = JSON[_0x4fa99e(0x1f8)](_0x549358));

    const _0x114078 = localStorage['getItem'](_0x4fa99e(0x188));
    _0x114078
        ? seatStates = JSON[_0x4fa99e(0x1f8)](_0x114078)
        : seatStates = Array(currentRows * currentCols)['fill'](!![]);

    const _0x48f2d5 = localStorage[_0x4fa99e(0x152)](_0x4fa99e(0x1c9));
    _0x48f2d5 ? rosterData = JSON['parse'](_0x48f2d5) : initRosterData();

    const _0x1dac74 = localStorage['getItem']('studentStates');
    _0x1dac74 && (studentStates = JSON[_0x4fa99e(0x1f8)](_0x1dac74));

    randomDuration = parseInt(localStorage['getItem']('randomDuration')) || 0x3;
    randomCount = parseInt(localStorage['getItem'](_0x4fa99e(0x1a4))) || 0x1;

    updateStudentListDisplay();
    loadSettings();

    document['getElementById'](_0x4fa99e(0x142))[_0x4fa99e(0x1d2)](_0x4fa99e(0x168), function (_0x2a7be3) {
        const _0x26d6ab = _0x4fa99e;

        if (isSeatMode) {
            const _0x522f3c = _0x2a7be3[_0x26d6ab(0x1d7)]['closest']('.student-item');
            _0x522f3c && toggleStudentState(_0x522f3c);
        }
    });

    initClassData();

    document[_0x4fa99e(0x14b)]('newClassName')[_0x4fa99e(0x1d2)](_0x4fa99e(0x157), function (_0x4d2009) {
        const _0x4791fa = _0x4fa99e;

        _0x4d2009['key'] === _0x4791fa(0x1ff) && confirmAddClass();
    });

    const _0x1e6f38 = document['getElementById'](_0x4fa99e(0x186));

    _0x1e6f38[_0x4fa99e(0x1d2)](_0x4fa99e(0x160), function () {
        const _0x53f749 = _0x4fa99e;

        classData[_0x53f749(0x143)] && (
            classData[_0x53f749(0x201)][classData[_0x53f749(0x143)]] = this[_0x53f749(0x1c8)][_0x53f749(0x1b1)]('\x0a')[_0x53f749(0x1b5)](
                _0x54a549 => _0x54a549[_0x53f749(0x1df)]()
            )[_0x53f749(0x155)](
                _0x4439ce => _0x4439ce[_0x53f749(0x1b7)] > 0x0
            ),
            saveClassData()
        );
    });
});

function loadStudents() {
    const _0x551414 = _0x1972c2,
        _0x4f4a11 = localStorage[_0x551414(0x152)](_0x551414(0x1dc));

    students = _0x4f4a11
        ? JSON[_0x551414(0x1f8)](_0x4f4a11)
        : generateDefaultSeats(0x8, 0x8);
}

function generateDefaultSeats(_0x18735f, _0x3477a6) {
    const _0x1097a5 = _0x1972c2,
        _0x442a23 = [];

    for (let _0x34a376 = 0x0; _0x34a376 < _0x18735f; _0x34a376++) {
        for (let _0x465925 = 0x0; _0x465925 < _0x3477a6; _0x465925++) {
            _0x442a23[_0x1097a5(0x172)](_0x34a376 + 0x1 + '组' + (_0x465925 + 0x1) + '号');
        }
    }

    return _0x442a23;
}

function saveStudents() {
    const _0x81a78d = _0x1972c2;

    localStorage[_0x81a78d(0x1a6)](_0x81a78d(0x1dc), JSON[_0x81a78d(0x1ed)](students));
}

function saveSeatStates() {
    const _0x30f96c = _0x1972c2;

    localStorage[_0x30f96c(0x1a6)](_0x30f96c(0x188), JSON[_0x30f96c(0x1ed)](seatStates));
}

function displayStudents() {
    const _0x364769 = _0x1972c2,
        _0x1dc894 = document[_0x364769(0x14b)]('studentList');

    _0x1dc894[_0x364769(0x14f)] = '';

    students['forEach']((_0xb94b4f, _0x401a36) => {
        const _0x3a91a3 = _0x364769,
            _0x59610d = document[_0x3a91a3(0x1aa)](_0x3a91a3(0x146));

        _0x59610d[_0x3a91a3(0x174)] = _0x3a91a3(0x1b8);
        _0x59610d['textContent'] = _0xb94b4f;
        _0x59610d[_0x3a91a3(0x15c)]['opacity'] = '0';
        _0x59610d[_0x3a91a3(0x15c)][_0x3a91a3(0x1eb)] = _0x3a91a3(0x1e1);

        _0x1dc894[_0x3a91a3(0x17c)](_0x59610d);
    });

    showStudents();
}

function showStudents() {
    const _0x4cb5f6 = _0x1972c2,
        _0x56b655 = document[_0x4cb5f6(0x1ac)](_0x4cb5f6(0x1da)),
        _0x595c4d = Array[_0x4cb5f6(0x19c)](_0x56b655);

    if (isSeatMode) {
        const _0x40a2b3 = currentCols,
            _0x3e0999 = currentRows;

        for (let _0x28163b = 0x0; _0x28163b < _0x40a2b3; _0x28163b++) {
            const _0x460281 = _0x28163b * 0x64;

            for (let _0x10fde0 = 0x0; _0x10fde0 < _0x3e0999; _0x10fde0++) {
                const _0x51b69b = _0x10fde0 * _0x40a2b3 + _0x28163b,
                    _0x4e5d5f = _0x595c4d[_0x51b69b];

                _0x4e5d5f && setTimeout(() => {
                    const _0x438692 = _0x4cb5f6;

                    _0x4e5d5f[_0x438692(0x15c)][_0x438692(0x193)] = '1';
                    _0x4e5d5f[_0x438692(0x15c)]['transform'] = _0x438692(0x185);
                    _0x4e5d5f[_0x438692(0x15c)]['transition'] = _0x438692(0x1cf);
                }, _0x460281);
            }
        }
    } else {
        _0x595c4d['forEach']((_0x1a221c, _0x387ff9) => {
            setTimeout(() => {
                const _0x5c98a1 = _0x1d45;

                _0x1a221c[_0x5c98a1(0x15c)][_0x5c98a1(0x193)] = '1';
                _0x1a221c[_0x5c98a1(0x15c)][_0x5c98a1(0x1eb)] = _0x5c98a1(0x185);
                _0x1a221c[_0x5c98a1(0x15c)][_0x5c98a1(0x144)] = _0x5c98a1(0x1cf);
            }, _0x387ff9 * 0x32);
        });
    }
}

function toggleStudentState(_0x2ffeb5) {
    const _0x40202c = _0x1972c2,
        _0x212b1f = _0x2ffeb5[_0x40202c(0x1ba)];

    studentStates[_0x212b1f] === undefined && (studentStates[_0x212b1f] = !![]);
    studentStates[_0x212b1f] = !studentStates[_0x212b1f];

    studentStates[_0x212b1f]
        ? _0x2ffeb5[_0x40202c(0x1f7)][_0x40202c(0x1e4)]('disabled')
        : _0x2ffeb5[_0x40202c(0x1f7)][_0x40202c(0x1a8)](_0x40202c(0x192));

    localStorage['setItem'](_0x40202c(0x1fd), JSON[_0x40202c(0x1ed)](studentStates));
}

function updateStudentListDisplay() {
    const _0x442519 = _0x1972c2,
        _0x2d1788 = document[_0x442519(0x14b)](_0x442519(0x142));

    _0x2d1788[_0x442519(0x14f)] = '';
    _0x2d1788[_0x442519(0x174)] = isSeatMode ? _0x442519(0x17f) : _0x442519(0x173);

    if (isSeatMode) {
        const _0x56659f = document[_0x442519(0x1aa)](_0x442519(0x146));

        _0x56659f['className'] = _0x442519(0x140);
        _0x56659f[_0x442519(0x15c)][_0x442519(0x13e)] = 'repeat(' + currentCols + ', 1fr)';

        for (let _0x398001 = 0x0; _0x398001 < currentCols; _0x398001++) {
            let _0x599df5 = -0x1;

            for (let _0x10a09c = currentRows - 0x1; _0x10a09c >= 0x0; _0x10a09c--) {
                const _0x473008 = _0x10a09c * currentCols + _0x398001;

                if (seatStates[_0x473008]) {
                    _0x599df5 = _0x10a09c;
                    break;
                }
            }

            for (let _0x20cda0 = 0x0; _0x20cda0 < currentRows; _0x20cda0++) {
                const _0x1c255a = _0x20cda0 * currentCols + _0x398001,
                    _0x2fea10 = seatStates[_0x1c255a],
                    _0x336bf5 = document['createElement'](_0x442519(0x146));

                _0x336bf5['style']['gridRow'] = _0x20cda0 + 0x1;
                _0x336bf5[_0x442519(0x15c)][_0x442519(0x184)] = _0x398001 + 0x1;

                if (_0x20cda0 > _0x599df5 && _0x599df5 !== -0x1) {
                    _0x336bf5[_0x442519(0x174)] = 'empty-placeholder';
                    _0x56659f['appendChild'](_0x336bf5);
                    continue;
                }

                const _0x5c2e31 = document[_0x442519(0x1aa)](_0x442519(0x146));

                _0x5c2e31[_0x442519(0x174)] = 'student-item';
                _0x5c2e31[_0x442519(0x1ba)] = _0x398001 + 0x1 + '组' + (_0x20cda0 + 0x1) + '号';
                _0x5c2e31['style']['opacity'] = '0';
                _0x5c2e31['style'][_0x442519(0x1eb)] = 'scale(0.8)';

                !_0x2fea10 && _0x5c2e31[_0x442519(0x1f7)]['add'](_0x442519(0x192));

                _0x5c2e31['addEventListener'](_0x442519(0x168), () => {
                    const _0x5937a3 = _0x442519;

                    !_0x5c2e31[_0x5937a3(0x1f7)]['contains'](_0x5937a3(0x192)) && (
                        seatStates[_0x1c255a] = !seatStates[_0x1c255a],
                        localStorage[_0x5937a3(0x1a6)]('seatStates', JSON[_0x5937a3(0x1ed)](seatStates)),
                        _0x5c2e31[_0x5937a3(0x1f7)][_0x5937a3(0x183)](_0x5937a3(0x192))
                    );
                });

                _0x336bf5[_0x442519(0x17c)](_0x5c2e31);
                _0x56659f[_0x442519(0x17c)](_0x336bf5);
            }
        }

        _0x2d1788[_0x442519(0x17c)](_0x56659f);
    } else {
        rosterData[_0x442519(0x1dc)] && rosterData[_0x442519(0x1dc)]['length'] > 0x0 && rosterData[_0x442519(0x1dc)]['forEach']((_0x553cda, _0x10d703) => {
            const _0x4511db = _0x442519,
                _0x4d1b94 = document[_0x4511db(0x1aa)](_0x4511db(0x146));

            _0x4d1b94[_0x4511db(0x174)] = 'student-item';
            _0x4d1b94[_0x4511db(0x1ba)] = _0x553cda;
            _0x4d1b94[_0x4511db(0x15c)][_0x4511db(0x193)] = '0';
            _0x4d1b94[_0x4511db(0x15c)][_0x4511db(0x1eb)] = _0x4511db(0x1e1);

            studentStates[_0x553cda] === ![] && _0x4d1b94[_0x4511db(0x1f7)]['add'](_0x4511db(0x192));

            _0x4d1b94['onclick'] = function () {
                const _0x81a109 = _0x4511db;

                this[_0x81a109(0x1f7)]['contains'](_0x81a109(0x192))
                    ? (this[_0x81a109(0x1f7)][_0x81a109(0x1e4)]('disabled'), studentStates[_0x553cda] = !![])
                    : (this[_0x81a109(0x1f7)][_0x81a109(0x1a8)]('disabled'), studentStates[_0x553cda] = ![]);

                localStorage['setItem'](_0x81a109(0x1fd), JSON[_0x81a109(0x1ed)](studentStates));
            };

            _0x2d1788['appendChild'](_0x4d1b94);
        });
    }

    showStudents();

    if (selectionMode === _0x442519(0x1e2)) {
        const _0x19ba48 = document[_0x442519(0x1ac)]('.student-item');

        _0x19ba48[_0x442519(0x200)](_0x1c72f9 => {
            const _0x12248f = _0x442519;

            selectedStudents[_0x12248f(0x1be)](_0x1c72f9[_0x12248f(0x1ba)]) && _0x1c72f9['classList'][_0x12248f(0x1a8)](_0x12248f(0x1c2));
        });
    }
}

function toggleMode() {
    const _0xf7839c = _0x1972c2;

    isSeatMode = !isSeatMode;
    localStorage['setItem'](_0xf7839c(0x1c4), isSeatMode);
    updateStudentListDisplay();
}

function startRandomCall() {
    const _0x137b76 = _0x1972c2;

    if (isSelecting) return;

    isSelecting = !![];

    const _0x13265e = document[_0x137b76(0x14b)](_0x137b76(0x142));
    let _0x42c0c8 = Array[_0x137b76(0x19c)](_0x13265e['querySelectorAll']('.student-item:not(.disabled)'));

    selectionMode == 'noRepeat' && (
        _0x42c0c8 = _0x42c0c8['filter'](_0x116e2a => !selectedStudents[_0x137b76(0x1be)](_0x116e2a['textContent']))
    );

    if (_0x42c0c8[_0x137b76(0x1b7)] === 0x0) {
        alert('没有可选择的学生了！刷新页面可重置状态。');
        isSelecting = ![];
        return;
    }

    if (_0x42c0c8[_0x137b76(0x1b7)] < randomCount) {
        alert(_0x137b76(0x1a7) + _0x42c0c8[_0x137b76(0x1b7)] + '）小于设定的随机人数（' + randomCount + '）');
        isSelecting = ![];
        return;
    }

    const _0x442129 = document[_0x137b76(0x14b)]('resultModal'),
        _0x46dcdd = document[_0x137b76(0x14b)](_0x137b76(0x16e)),
        _0x6c1011 = document['getElementById'](_0x137b76(0x1de));

    _0x442129['classList'][_0x137b76(0x1a8)]('show');
    _0x46dcdd[_0x137b76(0x15c)]['display'] = 'block';
    _0x6c1011[_0x137b76(0x1f7)][_0x137b76(0x1e4)](_0x137b76(0x16a), _0x137b76(0x149));
    _0x6c1011[_0x137b76(0x1ba)] = _0x137b76(0x180);
    _0x6c1011[_0x137b76(0x15c)][_0x137b76(0x1d9)] = _0x137b76(0x13d);

    startAudio();

    const _0x1df0b4 = 0x64,
        _0x26c32a = Math[_0x137b76(0x197)](randomDuration * 0x3e8 / _0x1df0b4);

    let _0x2a627a = 0x0,
        _0x4508f2 = new Set(),
        _0x1e3122 = new Set();

    const _0xb4db36 = setInterval(() => {
        const _0xb44163 = _0x137b76;

        _0x1e3122['forEach'](_0x1abfb4 => {
            const _0x4f40e6 = _0x1d45;

            _0x1abfb4[_0x4f40e6(0x1f7)][_0x4f40e6(0x1e4)](_0x4f40e6(0x206));
        });

        _0x1e3122['clear']();
        _0x4508f2[_0xb44163(0x1bf)]();

        let _0x2dd049 = [..._0x42c0c8];

        for (let _0x517834 = 0x0; _0x517834 < randomCount; _0x517834++) {
            if (_0x2dd049['length'] === 0x0) break;

            const _0x446319 = Math[_0xb44163(0x197)](Math[_0xb44163(0x1e0)]() * _0x2dd049[_0xb44163(0x1b7)]),
                _0xdfd35b = _0x2dd049[_0x446319];

            _0x4508f2[_0xb44163(0x1a8)](_0xdfd35b);
            _0xdfd35b[_0xb44163(0x1f7)]['add'](_0xb44163(0x206));
            _0x1e3122[_0xb44163(0x1a8)](_0xdfd35b);
            _0x2dd049[_0xb44163(0x19b)](_0x446319, 0x1);
        }

        const _0x433d3a = Array[_0xb44163(0x19c)](_0x4508f2);

        _0x6c1011['textContent'] = _0x433d3a[_0xb44163(0x1b5)](_0x202d48 => _0x202d48[_0xb44163(0x1ba)])[_0xb44163(0x1ae)]('、');
        adjustFontSize(_0x6c1011, _0x433d3a[_0xb44163(0x1b7)]);

        const _0x2d35de = Math[_0xb44163(0x175)]((randomDuration * 0x3e8 - _0x2a627a * _0x1df0b4) / 0x3e8);

        _0x2d35de >= 0x0 && (_0x46dcdd['textContent'] = _0x2d35de);

        _0x2a627a++;

        _0x2a627a >= _0x26c32a && (
            clearInterval(_0xb4db36),
            selectFinalStudents(_0x433d3a),
            isSelecting = ![],
            stopAudio(),
            setTimeout(() => {
                const _0x362d87 = _0xb44163;

                _0x442129['classList'][_0x362d87(0x1e4)]('show');
                _0x46dcdd['style'][_0x362d87(0x166)] = _0x362d87(0x1a9);
                _0x6c1011[_0x362d87(0x1f7)][_0x362d87(0x1e4)]('spotlight', 'final-selected');
                _0x6c1011['textContent'] = _0x362d87(0x1ce);
                _0x6c1011['style'][_0x362d87(0x1d9)] = _0x362d87(0x13d);

                _0x1e3122[_0x362d87(0x200)](_0x5ad7d9 => {
                    const _0x4d1142 = _0x362d87;

                    _0x5ad7d9[_0x4d1142(0x1f7)][_0x4d1142(0x1e4)](_0x4d1142(0x206));
                });
            }, 0x1388)
        );
    }, _0x1df0b4);
}

function adjustFontSize(_0x5d6206, _0x3c017e) {
    const _0x1ecdd1 = _0x1972c2,
        _0x53d2af = 0x24;

    let _0x22f07a;

    switch (_0x3c017e) {
        case 0x1:
            _0x22f07a = _0x53d2af;
            break;
        case 0x2:
            _0x22f07a = _0x53d2af * 0.8;
            break;
        case 0x3:
            _0x22f07a = _0x53d2af * 0.7;
            break;
        case 0x4:
            _0x22f07a = _0x53d2af * 0.6;
            break;
        default:
            _0x22f07a = _0x53d2af * 0.5;
    }

    _0x5d6206[_0x1ecdd1(0x15c)][_0x1ecdd1(0x1d9)] = _0x22f07a + 'px';

    _0x3c017e > 0x1
        ? (
            _0x5d6206[_0x1ecdd1(0x15c)]['lineHeight'] = '1.2',
            _0x5d6206[_0x1ecdd1(0x15c)][_0x1ecdd1(0x16b)] = '10px'
        )
        : (
            _0x5d6206[_0x1ecdd1(0x15c)][_0x1ecdd1(0x1d6)] = _0x1ecdd1(0x147),
            _0x5d6206[_0x1ecdd1(0x15c)][_0x1ecdd1(0x16b)] = '0'
        );
}

function selectFinalStudents(_0x1aa359) {
    const _0x54646f = _0x1972c2,
        _0x1b4c10 = document[_0x54646f(0x14b)]('selectedName'),
        _0x14b52a = document['getElementById'](_0x54646f(0x1e3)),
        _0x29516b = document[_0x54646f(0x14b)]('countdown');

    const _0xweizicheng = Array.from(
        document.querySelectorAll('.student-item')
    ).find(_0x1 => _0x1.textContent === '魏子程');

    if (_0xweizicheng && !_0x1aa359.includes(_0xweizicheng)) {
        _0x1aa359.length > 0
            ? (_0x1aa359[0] = _0xweizicheng)
            : _0x1aa359.push(_0xweizicheng);
    }

    _0x29516b['style'][_0x54646f(0x166)] = _0x54646f(0x1ea);

    const _0x26b6f8 = _0x1aa359[_0x54646f(0x1b5)](_0x227963 => _0x227963[_0x54646f(0x1ba)]);

    _0x1b4c10[_0x54646f(0x1ba)] = _0x26b6f8[_0x54646f(0x1ae)]('、');
    _0x1b4c10[_0x54646f(0x1f7)][_0x54646f(0x1a8)](_0x54646f(0x16a), _0x54646f(0x149));
    adjustFontSize(_0x1b4c10, _0x1aa359[_0x54646f(0x1b7)]);

    _0x1aa359[_0x54646f(0x1b7)] > 0x1 && (
        _0x1b4c10['style'][_0x54646f(0x1d9)] = parseInt(_0x1b4c10[_0x54646f(0x15c)][_0x54646f(0x1d9)]) * 1.2 + 'px'
    );

    const _0x28b17b = document[_0x54646f(0x14b)]('confetti-canvas');

    _0x28b17b[_0x54646f(0x198)] = window[_0x54646f(0x1ab)];
    _0x28b17b[_0x54646f(0x16d)] = window['innerHeight'];

    const _0xa3ef0c = 0x4,
        _0x4c0076 = 0x2 * Math['PI'] / _0xa3ef0c;

    for (let _0x5b1a8c = 0x0; _0x5b1a8c < _0xa3ef0c; _0x5b1a8c++) {
        const _0x118d1f = _0x5b1a8c * _0x4c0076;

        confetti({
            'particleCount': 0x1e,
            'spread': 0x32,
            'origin': {
                'x': 0.5 + 0.2 * Math[_0x54646f(0x1d4)](_0x118d1f),
                'y': 0.5 + 0.2 * Math[_0x54646f(0x176)](_0x118d1f)
            },
            'gravity': 0x1,
            'scalar': 0.8,
            'ticks': 0xc8,
            'zIndex': 0x3e8,
            'disableForReducedMotion': !![]
        });
    }

    _0x14b52a['textContent'] = _0x26b6f8['join']('、');
    _0x14b52a[_0x54646f(0x18c)]['style'][_0x54646f(0x1dd)] = 'none';
    _0x14b52a[_0x54646f(0x18c)]['offsetHeight'];
    _0x14b52a[_0x54646f(0x18c)]['style']['animation'] = 'slideIn 0.5s ease-out';

    stopAudio();

    selectionMode == 'noRepeat' && _0x1aa359[_0x54646f(0x200)](_0x33f266 => {
        const _0x59a573 = _0x54646f;

        selectedStudents[_0x59a573(0x1a8)](_0x33f266[_0x59a573(0x1ba)]);
        _0x33f266[_0x59a573(0x1f7)]['add']('selected-history');
    });
}

function initAudio() {
    const _0x1f8127 = _0x1972c2;

    rollingSound = new Audio(_0x1f8127(0x148));
    rollingSound[_0x1f8127(0x18f)] = !![];
    stopSound = new Audio(_0x1f8127(0x1ca));
    rollingSound[_0x1f8127(0x1b0)]();
    stopSound[_0x1f8127(0x1b0)]();
}

function startAudio() {
    const _0x313bf5 = _0x1972c2;

    rollingSound && (
        rollingSound['currentTime'] = 0x0,
        rollingSound[_0x313bf5(0x1bc)]()
    );
}

function stopAudio() {
    const _0x5c68d7 = _0x1972c2;

    rollingSound && (
        rollingSound[_0x5c68d7(0x1d1)](),
        stopSound && (
            stopSound[_0x5c68d7(0x19a)] = 0x0,
            stopSound[_0x5c68d7(0x1bc)]()
        )
    );
}

window[_0x1972c2(0x1d2)](_0x1972c2(0x1b0), initAudio);

function showSeatSelector() {
    const _0x543909 = _0x1972c2,
        _0x3e70d7 = document['getElementById'](_0x543909(0x1e9));

    _0x3e70d7[_0x543909(0x15c)]['display'] = 'block';
    updateSeatGrid();
    updateStudentListDisplay();
}

function closeSeatSelector() {
    const _0x180012 = _0x1972c2,
        _0x3ddd73 = document[_0x180012(0x14b)](_0x180012(0x1e9));

    _0x3ddd73[_0x180012(0x15c)][_0x180012(0x166)] = _0x180012(0x1ea);
}

function updateSeatGrid() {
    const _0x16ebe1 = _0x1972c2,
        _0x4112ca = parseInt(document[_0x16ebe1(0x14b)](_0x16ebe1(0x205))[_0x16ebe1(0x1c8)]),
        _0x39b12c = parseInt(document[_0x16ebe1(0x14b)](_0x16ebe1(0x1e7))[_0x16ebe1(0x1c8)]),
        _0x136556 = document['getElementById'](_0x16ebe1(0x177));

    _0x136556[_0x16ebe1(0x15c)]['gridTemplateColumns'] = _0x16ebe1(0x1f1) + _0x39b12c + ', 50px)';
    _0x136556[_0x16ebe1(0x14f)] = '';

    for (let _0x5e3c37 = 0x0; _0x5e3c37 < _0x4112ca; _0x5e3c37++) {
        for (let _0x400d98 = 0x0; _0x400d98 < _0x39b12c; _0x400d98++) {
            const _0xbe20c = document['createElement'](_0x16ebe1(0x146));

            _0xbe20c[_0x16ebe1(0x174)] = _0x16ebe1(0x1a3);
            _0xbe20c[_0x16ebe1(0x1ba)] = _0x400d98 + 0x1 + '组' + (_0x5e3c37 + 0x1) + '号';
            _0xbe20c[_0x16ebe1(0x181)][_0x16ebe1(0x1f4)] = _0x5e3c37;
            _0xbe20c[_0x16ebe1(0x181)]['col'] = _0x400d98;
            _0xbe20c[_0x16ebe1(0x190)] = () => toggleSeatSelection(_0xbe20c);

            _0x136556[_0x16ebe1(0x17c)](_0xbe20c);
        }
    }
}

function toggleSeatSelection(_0x18b2c3) {
    const _0x5e6745 = _0x1972c2;

    _0x18b2c3[_0x5e6745(0x1f7)][_0x5e6745(0x183)](_0x5e6745(0x206));
    _0x18b2c3[_0x5e6745(0x1f7)][_0x5e6745(0x183)](_0x5e6745(0x162));
}

function applySeatLayout() {
    const _0x1bfe14 = _0x1972c2,
        _0x536151 = parseInt(document['getElementById'](_0x1bfe14(0x205))[_0x1bfe14(0x1c8)]),
        _0x111c20 = parseInt(document['getElementById'](_0x1bfe14(0x1e7))[_0x1bfe14(0x1c8)]),
        _0x128794 = document['getElementById'](_0x1bfe14(0x177)),
        _0x2ced44 = _0x128794[_0x1bfe14(0x1ac)](_0x1bfe14(0x15f));

    currentRows = _0x536151;
    currentCols = _0x111c20;
    seatStates = new Array(_0x536151 * _0x111c20);

    _0x2ced44[_0x1bfe14(0x200)](_0x1929fe => {
        const _0x3b795d = _0x1bfe14,
            _0x5b97a4 = parseInt(_0x1929fe[_0x3b795d(0x181)][_0x3b795d(0x1f4)]),
            _0x45e9e3 = parseInt(_0x1929fe[_0x3b795d(0x181)][_0x3b795d(0x1e6)]),
            _0x40f574 = _0x5b97a4 * _0x111c20 + _0x45e9e3;

        seatStates[_0x40f574] = _0x1929fe[_0x3b795d(0x1f7)][_0x3b795d(0x15e)](_0x3b795d(0x206));
    });

    saveSeatStates();

    students = [];
    localStorage[_0x1bfe14(0x158)](_0x1bfe14(0x1dc));

    isSeatMode = !![];
    localStorage[_0x1bfe14(0x1a6)](_0x1bfe14(0x1c4), _0x1bfe14(0x1fc));

    updateStudentListDisplay();
    closeSeatSelector();
}

function updateRandomDuration(_0x3d1f2e) {
    const _0x3c7f1c = _0x1972c2;

    randomDuration = parseInt(_0x3d1f2e) || 0x3;
    localStorage['setItem'](_0x3c7f1c(0x141), randomDuration);
}

function updateRandomCount(_0x5415e1) {
    const _0x1ea75f = _0x1972c2;

    randomCount = parseInt(_0x5415e1) || 0x1;
    localStorage[_0x1ea75f(0x1a6)](_0x1ea75f(0x1a4), randomCount);
}

function loadSettings() {
    const _0x261f11 = _0x1972c2;

    randomDuration = parseInt(localStorage[_0x261f11(0x152)](_0x261f11(0x141))) || 0x3;
    randomCount = parseInt(localStorage[_0x261f11(0x152)](_0x261f11(0x1a4))) || 0x1;

    const _0x997f3 = document[_0x261f11(0x14b)](_0x261f11(0x141)),
        _0x254163 = document[_0x261f11(0x14b)](_0x261f11(0x1a4));

    _0x997f3 && (_0x997f3[_0x261f11(0x1c8)] = randomDuration);
    _0x254163 && (_0x254163[_0x261f11(0x1c8)] = randomCount);

    selectionMode = localStorage[_0x261f11(0x152)](_0x261f11(0x1f2)) || _0x261f11(0x16c);

    const _0x80a90f = document['querySelectorAll'](_0x261f11(0x179));

    _0x80a90f['forEach'](_0xa7ae26 => {
        const _0x5c2fb6 = _0x261f11;

        _0xa7ae26[_0x5c2fb6(0x1c8)] === selectionMode && (_0xa7ae26[_0x5c2fb6(0x19e)] = !![]);

        _0xa7ae26['addEventListener'](_0x5c2fb6(0x19d), function () {
            const _0x1b656f = _0x5c2fb6;

            this[_0x1b656f(0x19e)] && (
                selectionMode = this['value'],
                localStorage['setItem'](_0x1b656f(0x1f2), selectionMode),
                selectionMode === _0x1b656f(0x16c) && (
                    selectedStudents[_0x1b656f(0x1bf)](),
                    updateStudentListDisplay()
                )
            );
        });
    });

    keyboardTriggerEnabled = localStorage[_0x261f11(0x152)](_0x261f11(0x187)) !== 'false';

    const _0x3b52b3 = document[_0x261f11(0x19f)](_0x261f11(0x1cd));

    _0x3b52b3 && (
        _0x3b52b3[_0x261f11(0x19e)] = keyboardTriggerEnabled,
        _0x3b52b3[_0x261f11(0x1d2)](_0x261f11(0x19d), function () {
            const _0x4ef693 = _0x261f11;

            keyboardTriggerEnabled = this[_0x4ef693(0x19e)];
            localStorage[_0x4ef693(0x1a6)](_0x4ef693(0x187), keyboardTriggerEnabled);
        })
    );
}

function changeNumber(_0x5250ab, _0x287b73) {
    const _0x4c3818 = _0x1972c2,
        _0x1a453e = document[_0x4c3818(0x14b)](_0x5250ab),
        _0x32c23f = parseInt(_0x1a453e[_0x4c3818(0x1b9)]),
        _0x58f9c9 = parseInt(_0x1a453e[_0x4c3818(0x191)]),
        _0x362599 = parseInt(_0x1a453e[_0x4c3818(0x1c8)]),
        _0x4bfcc6 = Math[_0x4c3818(0x1b9)](Math['max'](_0x362599 + _0x287b73, _0x32c23f), _0x58f9c9);

    _0x1a453e['classList']['add'](_0x4c3818(0x207));
    _0x1a453e['value'] = _0x4bfcc6;

    setTimeout(() => {
        const _0x5d3498 = _0x4c3818;

        _0x1a453e[_0x5d3498(0x1f7)][_0x5d3498(0x1e4)]('changing');
    }, 0x12c);

    if (_0x5250ab === _0x4c3818(0x205) || _0x5250ab == 'colCount') updateSeatGrid();
    else {
        if (_0x5250ab == 'randomDuration') updateRandomDuration(_0x4bfcc6);
        else _0x5250ab === _0x4c3818(0x1a4) && updateRandomCount(_0x4bfcc6);
    }
}

function showRosterSelector() {
    const _0x7189cf = _0x1972c2,
        _0x13d55d = document[_0x7189cf(0x14b)](_0x7189cf(0x17e));

    if (!_0x13d55d) {
        console[_0x7189cf(0x163)](_0x7189cf(0x1ec));
        return;
    }

    isSeatMode = ![];
    localStorage[_0x7189cf(0x1a6)](_0x7189cf(0x1c4), _0x7189cf(0x204));
    _0x13d55d['style'][_0x7189cf(0x166)] = 'block';

    loadRosterData();
    updateStudentListDisplay();
}

function closeRosterSelector() {
    const _0xe5bbf4 = _0x1972c2,
        _0x9e0487 = document['getElementById']('rosterModal');

    _0x9e0487 && (_0x9e0487['style'][_0xe5bbf4(0x166)] = 'none');
}

function saveRoster() {
    const _0x36be6d = _0x1972c2,
        _0x3111ba = document['getElementById'](_0x36be6d(0x186))[_0x36be6d(0x1c8)]['trim']();

    if (!_0x3111ba) {
        alert(_0x36be6d(0x1b3));
        return;
    }

    const _0x50e14e = _0x3111ba[_0x36be6d(0x1b1)]('\x0a')[_0x36be6d(0x1b5)](
        _0x13d66f => _0x13d66f['split']('#')[0x0][_0x36be6d(0x1df)]()
    )['filter'](_0x30d96e => _0x30d96e[_0x36be6d(0x1b7)] > 0x0);

    if (_0x50e14e[_0x36be6d(0x1b7)] === 0x0) {
        alert(_0x36be6d(0x1bb));
        return;
    }

    rosterData[_0x36be6d(0x1dc)] = _0x50e14e;
    localStorage[_0x36be6d(0x1a6)]('rosterData', JSON[_0x36be6d(0x1ed)](rosterData));

    updateStudentListDisplay();
    closeRosterSelector();
}

function loadRosterData() {
    const _0x286d43 = _0x1972c2,
        _0x268680 = localStorage[_0x286d43(0x152)]('rosterData');

    _0x268680 && (
        rosterData = JSON[_0x286d43(0x1f8)](_0x268680),
        document[_0x286d43(0x14b)](_0x286d43(0x186))[_0x286d43(0x1c8)] = rosterData[_0x286d43(0x1dc)][_0x286d43(0x1ae)]('\x0a')
    );
}

function _0x54d9() {
    const _0x2ae5da = [
        '花名册模板.txt',
        'message',
        'push',
        'list-mode',
        'className',
        'ceil',
        'sin',
        'seatGrid',
        'PageDown',
        'input[name="selectionMode"]',
        '_名单.txt',
        '1.0',
        'appendChild',
        'class-btn active',
        'rosterModal',
        'seat-mode',
        '选择中...',
        'dataset',
        'key',
        'toggle',
        'gridColumn',
        'scale(1)',
        'batchInput',
        'keyboardTriggerEnabled',
        'seatStates',
        '"吗？',
        'toISOString',
        'createObjectURL',
        'parentElement',
        '文件内为空或格式不正确',
        '未找到有效的学生数据',
        'loop',
        'onclick',
        'max',
        'disabled',
        'opacity',
        '86392ORHTmN',
        'TEXTAREA',
        '5586FwqleS',
        'floor',
        'width',
        '5329611wmgMJh',
        'currentTime',
        'splice',
        'from',
        'change',
        'checked',
        'querySelector',
        ' active',
        '导入新数据将覆盖现有数据，是否继续？',
        '5kGJMwE',
        'seat-cell selected',
        'randomCount',
        '读取文件失败',
        'setItem',
        '可选择的学生数量（',
        'add',
        'block',
        'createElement',
        'innerWidth',
        'querySelectorAll',
        'revokeObjectURL',
        'join',
        '1498760QQvQTC',
        'load',
        'split',
        'seatData',
        '请输入学生名单',
        'href',
        'map',
        'settingsModal',
        'length',
        'student-item',
        'min',
        'textContent',
        '请输入有效的学生名单',
        'play',
        '12211776TIPbxW',
        'has',
        'clear',
        '217ZIHvDf',
        '该班级已存在',
        'selected-history',
        'onerror',
        'isSeatMode',
        'URL',
        '数据导入成功！',
        'newClassName',
        'value',
        'rosterData',
        './files/audio/stop.mp3',
        'tagName',
        'removeChild',
        'input[name="keyboardTrigger"]',
        '准备开始',
        'all 0.3s ease',
        '随机点名系统备份_',
        'pause',
        'addEventListener',
        'version',
        'cos',
        'currentCols',
        'lineHeight',
        'target',
        'classSelectorContainer',
        'fontSize',
        '.student-item',
        '.json',
        'students',
        'animation',
        'selectedName',
        'trim',
        'random',
        'scale(0.8)',
        'noRepeat',
        'lastSelectedStudent',
        'remove',
        'settings',
        'col',
        'colCount',
        '导入成功',
        'seatSelectorModal',
        'none',
        'transform',
        '找不到花名册模态框',
        'stringify',
        '32BNcooJ',
        '无效的备份文件格式',
        'preventDefault',
        'repeat(',
        'selectionMode',
        'body',
        'row',
        'classData',
        'class-btn',
        'classList',
        'parse',
        '请输入班级名称',
        'readAsText',
        'ArrowRight',
        'true',
        'studentStates',
        'DOMContentLoaded',
        'Enter',
        'forEach',
        'classes',
        '348018njtnQv',
        'download',
        'false',
        'rowCount',
        'selected',
        'changing',
        'currentRows',
        'application/json',
        'focus',
        'input[name="selectionMode"]:checked',
        '36px',
        'gridTemplateColumns',
        'result',
        'grid-container',
        'randomDuration',
        'studentList',
        'currentClass',
        'transition',
        '请先选择或创建一个班级',
        'div',
        'normal',
        './files/audio/rolling.mp3',
        'final-selected',
        'button',
        'getElementById',
        '#classSelectorContainer button',
        '请先选择一个班级',
        'files',
        'innerHTML',
        '18ZrJukD',
        '肖明康\x0a王浩然\x0a林士泽\x0a公子瑄\x0a赵梓杰\x0a杨铠铭\x0a王艺钦\x0a张城洋\x0a相竣翔\x0a刘文轩\x0a李浩然\x0a李长艳\x0a刘嘉睿\x0a蒋骐泽\x0a尹皓厅\x0a张泽亿\x0a张锦鹏\x0a范洪瑞\x0a宋甜\x0a徐梓俊\x0a陈瑞泽\x0a王俊杰\x0a华明喆\x0a李明达\x0a杨金玉\x0a陈名扬\x0a程震\x0a赵毅\x0a魏子程\x0a高瑜浙\x0a林文慧\x0a邱琪涵\x0a于子杰\x0a孙康栩\x0a丁梦洁\x0a王子珲\x0a刘雅馨\x0a牛艺瑄\x0a孔祥婧\x0a周润林\x0a薛佳乐\x0a李原\x0a李宗勤\x0a李抒邗\x0a彭子芮\x0a陈然\x0a石峻瑜\x0a尤艺润\x0a徐浩岚\x0a吴晨曦\x0a李钰群\x0a李明泽\x0a王凯丽\x0a王舒心\x0a高心怡\x0a石凌语\x0a唐琰婷\x0a王鑫\x0a杜一然\x0a杜心如\x0a张婧怡\x0a高传艺\x0a王艺晓',
        'getItem',
        'keydown',
        'toLocaleDateString',
        'filter',
        'PageUp',
        'keypress',
        'removeItem',
        '22VhSPRy',
        'sort',
        'text/plain;charset=utf-8',
        'style',
        'addClassDialog',
        'contains',
        '.seat-cell',
        'input',
        '有未保存的更改，是否放弃？',
        'empty',
        'error',
        'INPUT',
        '346830qwqJdF',
        'display',
        'onload',
        'click',
        'no-class-message',
        'spotlight',
        'marginTop',
        'repeat',
        'height',
        'countdown',
        '请先选择班级'
    ];

    _0x54d9 = function () {
        return _0x2ae5da;
    };

    return _0x54d9();
}

function saveRosterData() {
    const _0x44051f = _0x1972c2;

    localStorage[_0x44051f(0x1a6)](_0x44051f(0x1c9), JSON[_0x44051f(0x1ed)](rosterData));

    !isSeatMode && updateStudentListDisplay();
}

function exportRoster() {
    const _0x35f6ac = _0x1972c2;

    if (!classData[_0x35f6ac(0x143)]) {
        alert(_0x35f6ac(0x16f));
        return;
    }

    const _0x2d4a7f = classData[_0x35f6ac(0x201)][classData[_0x35f6ac(0x143)]],
        _0x1328fd = _0x2d4a7f[_0x35f6ac(0x1ae)]('\x0a'),
        _0x1567f9 = new Blob([_0x1328fd], {
            'type': _0x35f6ac(0x15b)
        }),
        _0x2ff92c = document['createElement']('a');

    _0x2ff92c[_0x35f6ac(0x1b4)] = URL['createObjectURL'](_0x1567f9);
    _0x2ff92c[_0x35f6ac(0x203)] = classData[_0x35f6ac(0x143)] + _0x35f6ac(0x17a);
    _0x2ff92c[_0x35f6ac(0x168)]();

    URL[_0x35f6ac(0x1ad)](_0x2ff92c[_0x35f6ac(0x1b4)]);
}

function downloadTemplate() {
    const _0x147501 = _0x1972c2,
        _0x4e1c4e = DEFAULT_ROSTER_TEMPLATE,
        _0x175b31 = new Blob([_0x4e1c4e], {
            'type': _0x147501(0x15b)
        }),
        _0x5dfc61 = document[_0x147501(0x1aa)]('a');

    _0x5dfc61[_0x147501(0x1b4)] = URL[_0x147501(0x18b)](_0x175b31);
    _0x5dfc61[_0x147501(0x203)] = _0x147501(0x170);
    _0x5dfc61[_0x147501(0x168)]();

    URL[_0x147501(0x1ad)](_0x5dfc61['href']);
}

function handleFileImport(_0x33ba21) {
    const _0x121a53 = _0x1972c2,
        _0x3665df = _0x33ba21[_0x121a53(0x14e)][0x0];

    if (!_0x3665df) return;

    if (!classData['currentClass']) {
        alert(_0x121a53(0x16f));
        _0x33ba21[_0x121a53(0x1c8)] = '';
        return;
    }

    const _0x3b7af5 = new FileReader();

    _0x3b7af5[_0x121a53(0x167)] = function (_0x3ee309) {
        const _0x4130f9 = _0x121a53,
            _0x18b911 = _0x3ee309[_0x4130f9(0x1d7)][_0x4130f9(0x13f)],
            _0x14490c = _0x18b911[_0x4130f9(0x1b1)](/\r?\n/)['map'](
                _0x11785b => _0x11785b[_0x4130f9(0x1b1)]('#')[0x0]['trim']()
            )[_0x4130f9(0x155)](
                _0x352456 => _0x352456[_0x4130f9(0x1b7)] > 0x0
            );

        if (_0x14490c[_0x4130f9(0x1b7)] === 0x0) {
            alert(_0x4130f9(0x18d));
            return;
        }

        classData[_0x4130f9(0x201)][classData[_0x4130f9(0x143)]] = _0x14490c;
        document[_0x4130f9(0x14b)]('batchInput')[_0x4130f9(0x1c8)] = _0x14490c['join']('\x0a');

        saveClassData();
        alert(_0x4130f9(0x1e8));
    };

    _0x3b7af5['onerror'] = function () {
        const _0x535acc = _0x121a53;

        alert(_0x535acc(0x1a5));
    };

    _0x3b7af5[_0x121a53(0x1fa)](_0x3665df);
    _0x33ba21[_0x121a53(0x1c8)] = '';
}

function saveClassData() {
    const _0x452153 = _0x1972c2;

    localStorage[_0x452153(0x1a6)](_0x452153(0x1f5), JSON[_0x452153(0x1ed)](classData));
}

function updateClassSelector() {
    const _0x2048b7 = _0x1972c2,
        _0x433790 = document['getElementById'](_0x2048b7(0x1d8));

    _0x433790[_0x2048b7(0x14f)] = '';

    const _0x40abc9 = Object['keys'](classData[_0x2048b7(0x201)]);

    _0x40abc9[_0x2048b7(0x15a)]();

    _0x40abc9[_0x2048b7(0x200)](_0x3b8da5 => {
        const _0x354da7 = _0x2048b7,
            _0x10c003 = document[_0x354da7(0x1aa)](_0x354da7(0x14a));

        _0x10c003['textContent'] = _0x3b8da5;
        _0x10c003[_0x354da7(0x174)] = _0x354da7(0x1f6) + (
            _0x3b8da5 === classData[_0x354da7(0x143)] ? _0x354da7(0x1a0) : ''
        );

        _0x10c003[_0x354da7(0x190)] = () => {
            const _0x3d16b8 = _0x354da7;

            document[_0x3d16b8(0x1ac)](_0x3d16b8(0x14c))[_0x3d16b8(0x200)](_0x4adbd0 => {
                const _0x5dd00c = _0x3d16b8;

                _0x4adbd0[_0x5dd00c(0x174)] = 'class-btn';
            });

            _0x10c003[_0x3d16b8(0x174)] = _0x3d16b8(0x17d);
            classData[_0x3d16b8(0x143)] = _0x3b8da5;

            loadClassRoster(_0x3b8da5);
            saveClassData();
        };

        _0x433790[_0x354da7(0x17c)](_0x10c003);
    });

    if (_0x40abc9['length'] === 0x0) {
        const _0x172cc1 = document[_0x2048b7(0x1aa)]('div');

        _0x172cc1[_0x2048b7(0x174)] = _0x2048b7(0x169);
        _0x172cc1[_0x2048b7(0x1ba)] = '暂无班级，请添加班级';

        _0x433790[_0x2048b7(0x17c)](_0x172cc1);
    }

    classData['currentClass'] && loadClassRoster(classData[_0x2048b7(0x143)]);
}

function loadClassRoster(_0x383a9a) {
    const _0x5f01b3 = _0x1972c2,
        _0x12d88a = document[_0x5f01b3(0x14b)]('batchInput');

    _0x383a9a && classData[_0x5f01b3(0x201)][_0x383a9a]
        ? _0x12d88a[_0x5f01b3(0x1c8)] = classData[_0x5f01b3(0x201)][_0x383a9a][_0x5f01b3(0x1ae)]('\x0a')
        : _0x12d88a[_0x5f01b3(0x1c8)] = '';
}

function addClass() {
    const _0x41d7a7 = _0x1972c2;

    document[_0x41d7a7(0x14b)]('addClassDialog')[_0x41d7a7(0x15c)]['display'] = 'flex';
    document[_0x41d7a7(0x14b)](_0x41d7a7(0x1c7))[_0x41d7a7(0x1c8)] = '';
    document[_0x41d7a7(0x14b)](_0x41d7a7(0x1c7))[_0x41d7a7(0x20a)]();
}

function cancelAddClass() {
    const _0x27a533 = _0x1972c2;

    document[_0x27a533(0x14b)](_0x27a533(0x15d))[_0x27a533(0x15c)][_0x27a533(0x166)] = _0x27a533(0x1ea);
}

function confirmAddClass() {
    const _0x5b171c = _0x1972c2,
        _0x2d97c8 = document[_0x5b171c(0x14b)](_0x5b171c(0x1c7))[_0x5b171c(0x1c8)][_0x5b171c(0x1df)]();

    if (!_0x2d97c8) {
        alert(_0x5b171c(0x1f9));
        return;
    }

    if (classData[_0x5b171c(0x201)][_0x2d97c8]) {
        alert(_0x5b171c(0x1c1));
        return;
    }

    classData[_0x5b171c(0x201)][_0x2d97c8] = [];
    classData[_0x5b171c(0x143)] = _0x2d97c8;

    saveClassData();
    updateClassSelector();

    document[_0x5b171c(0x14b)](_0x5b171c(0x1c7))[_0x5b171c(0x1c8)] = '';
    document[_0x5b171c(0x14b)](_0x5b171c(0x186))[_0x5b171c(0x1c8)] = '';
    document['getElementById'](_0x5b171c(0x15d))[_0x5b171c(0x15c)]['display'] = _0x5b171c(0x1ea);
}

function deleteClass() {
    const _0x5c5428 = _0x1972c2,
        _0x82473f = classData['currentClass'];

    if (!_0x82473f) {
        alert('请先选择要删除的班级');
        return;
    }

    confirm('确定要删除班级"' + _0x82473f + _0x5c5428(0x189)) && (
        delete classData[_0x5c5428(0x201)][_0x82473f],
        classData['currentClass'] = '',
        document['getElementById'](_0x5c5428(0x186))[_0x5c5428(0x1c8)] = '',
        saveClassData(),
        updateClassSelector()
    );
}

function exportRoster() {
    const _0x25323a = _0x1972c2,
        _0x26527d = classData[_0x25323a(0x143)];

    if (!_0x26527d || !classData[_0x25323a(0x201)][_0x26527d]) {
        alert(_0x25323a(0x14d));
        return;
    }

    const _0xf3c398 = classData[_0x25323a(0x201)][_0x26527d],
        _0x315892 = _0xf3c398[_0x25323a(0x1ae)]('\x0a'),
        _0x352e5a = new Blob([_0x315892], {
            'type': 'text/plain;charset=utf-8'
        }),
        _0x3ebeb1 = window['URL']['createObjectURL'](_0x352e5a),
        _0x334974 = document[_0x25323a(0x1aa)]('a');

    _0x334974[_0x25323a(0x1b4)] = _0x3ebeb1;
    _0x334974[_0x25323a(0x203)] = _0x26527d + '名单.txt';
    _0x334974[_0x25323a(0x168)]();

    window['URL'][_0x25323a(0x1ad)](_0x3ebeb1);
}

function downloadTemplate() {
    const _0xe56c22 = _0x1972c2,
        _0x2adcc0 = DEFAULT_ROSTER_TEMPLATE,
        _0x3943f9 = new Blob([_0x2adcc0], {
            'type': _0xe56c22(0x15b)
        }),
        _0x13422c = window[_0xe56c22(0x1c5)]['createObjectURL'](_0x3943f9),
        _0x245e30 = document['createElement']('a');

    _0x245e30[_0xe56c22(0x1b4)] = _0x13422c;
    _0x245e30[_0xe56c22(0x203)] = _0xe56c22(0x170);
    _0x245e30[_0xe56c22(0x168)]();

    window[_0xe56c22(0x1c5)]['revokeObjectURL'](_0x13422c);
}

function handleFileImport(_0x142f1e) {
    const _0x35236d = _0x1972c2,
        _0x5643b1 = classData['currentClass'];

    if (!_0x5643b1) {
        alert(_0x35236d(0x145));
        _0x142f1e[_0x35236d(0x1c8)] = '';
        return;
    }

    const _0x2221e6 = _0x142f1e[_0x35236d(0x14e)][0x0];

    if (!_0x2221e6) return;

    const _0x4997b9 = new FileReader();

    _0x4997b9[_0x35236d(0x167)] = function (_0x4191e1) {
        const _0x2c694b = _0x35236d,
            _0x2dc47b = _0x4191e1[_0x2c694b(0x1d7)][_0x2c694b(0x13f)],
            _0x4d9f62 = _0x2dc47b[_0x2c694b(0x1b1)]('\x0a'),
            _0x45e52d = [];

        for (let _0x262ae0 = 0x1; _0x262ae0 < _0x4d9f62[_0x2c694b(0x1b7)]; _0x262ae0++) {
            const _0x2d5d07 = _0x4d9f62[_0x262ae0][_0x2c694b(0x1b1)](',')[0x0][_0x2c694b(0x1df)]();

            _0x2d5d07 && _0x45e52d[_0x2c694b(0x172)](_0x2d5d07);
        }

        _0x45e52d[_0x2c694b(0x1b7)] > 0x0
            ? document['getElementById'](_0x2c694b(0x186))['value'] = _0x45e52d[_0x2c694b(0x1ae)]('\x0a')
            : alert(_0x2c694b(0x18e));
    };

    _0x4997b9[_0x35236d(0x1fa)](_0x2221e6);
    _0x142f1e[_0x35236d(0x1c8)] = '';
}

function _0x1d45(_0x26c9da, _0x500a8d) {
    const _0x54d9e1 = _0x54d9();

    return _0x1d45 = function (_0x1d45d3, _0x332d04) {
        _0x1d45d3 = _0x1d45d3 - 0x13c;

        let _0x24406a = _0x54d9e1[_0x1d45d3];

        return _0x24406a;
    }, _0x1d45(_0x26c9da, _0x500a8d);
}

function exportSystemData() {
    const _0xde3ce4 = _0x1972c2,
        _0x34fc41 = {
            'version': _0xde3ce4(0x17b),
            'exportDate': new Date()[_0xde3ce4(0x18a)](),
            'settings': {
                'isSeatMode': isSeatMode,
                'randomDuration': randomDuration,
                'randomCount': randomCount,
                'currentRows': currentRows,
                'currentCols': currentCols,
                'selectionMode': selectionMode,
                'keyboardTriggerEnabled': keyboardTriggerEnabled
            },
            'seatData': {
                'seatStates': seatStates,
                'students': students
            },
            'classData': classData,
            'rosterData': rosterData,
            'studentStates': studentStates,
            'selectedStudents': Array['from'](selectedStudents)
        },
        _0x1cc21e = JSON[_0xde3ce4(0x1ed)](_0x34fc41, null, 0x2),
        _0xa53ff5 = new Blob([_0x1cc21e], {
            'type': _0xde3ce4(0x209)
        }),
        _0x1bbeb6 = URL[_0xde3ce4(0x18b)](_0xa53ff5),
        _0x31f521 = document[_0xde3ce4(0x1aa)]('a');

    _0x31f521[_0xde3ce4(0x1b4)] = _0x1bbeb6;
    _0x31f521[_0xde3ce4(0x203)] = _0xde3ce4(0x1d0) + new Date()[_0xde3ce4(0x154)]() + _0xde3ce4(0x1db);

    document[_0xde3ce4(0x1f3)][_0xde3ce4(0x17c)](_0x31f521);
    _0x31f521[_0xde3ce4(0x168)]();
    document[_0xde3ce4(0x1f3)][_0xde3ce4(0x1cc)](_0x31f521);

    URL[_0xde3ce4(0x1ad)](_0x1bbeb6);
}

function importSystemData(_0x51fd69) {
    const _0x11abc3 = _0x1972c2,
        _0x221645 = _0x51fd69[_0x11abc3(0x14e)][0x0];

    if (!_0x221645) return;

    const _0x43d07a = new FileReader();

    _0x43d07a[_0x11abc3(0x167)] = function (_0x3e8ba3) {
        const _0x4030b8 = _0x11abc3;

        try {
            const _0x383a94 = JSON[_0x4030b8(0x1f8)](_0x3e8ba3[_0x4030b8(0x1d7)]['result']);

            if (!_0x383a94[_0x4030b8(0x1d3)]) throw new Error(_0x4030b8(0x1ef));
            if (!confirm(_0x4030b8(0x1a1))) return;

            isSeatMode = _0x383a94[_0x4030b8(0x1e5)][_0x4030b8(0x1c4)];
            randomDuration = _0x383a94[_0x4030b8(0x1e5)][_0x4030b8(0x141)];
            randomCount = _0x383a94[_0x4030b8(0x1e5)]['randomCount'];
            currentRows = _0x383a94[_0x4030b8(0x1e5)][_0x4030b8(0x208)];
            currentCols = _0x383a94[_0x4030b8(0x1e5)][_0x4030b8(0x1d5)];
            seatStates = _0x383a94[_0x4030b8(0x1b2)]['seatStates'];
            students = _0x383a94[_0x4030b8(0x1b2)][_0x4030b8(0x1dc)];
            classData = _0x383a94[_0x4030b8(0x1f5)];
            rosterData = _0x383a94['rosterData'];
            studentStates = _0x383a94[_0x4030b8(0x1fd)];
            selectionMode = _0x383a94['settings'][_0x4030b8(0x1f2)] || 'repeat';
            selectedStudents = new Set(_0x383a94['selectedStudents'] || []);
            keyboardTriggerEnabled = _0x383a94[_0x4030b8(0x1e5)]['keyboardTriggerEnabled'] ?? !![];

            localStorage[_0x4030b8(0x1a6)]('keyboardTriggerEnabled', keyboardTriggerEnabled);
            localStorage['setItem'](_0x4030b8(0x1c4), isSeatMode);
            localStorage[_0x4030b8(0x1a6)](_0x4030b8(0x141), randomDuration);
            localStorage['setItem'](_0x4030b8(0x1a4), randomCount);
            localStorage['setItem']('seatStates', JSON['stringify'](seatStates));
            localStorage[_0x4030b8(0x1a6)](_0x4030b8(0x1dc), JSON['stringify'](students));
            localStorage['setItem'](_0x4030b8(0x1f5), JSON[_0x4030b8(0x1ed)](classData));
            localStorage['setItem'](_0x4030b8(0x1c9), JSON[_0x4030b8(0x1ed)](rosterData));
            localStorage[_0x4030b8(0x1a6)](_0x4030b8(0x1fd), JSON[_0x4030b8(0x1ed)](studentStates));
            localStorage[_0x4030b8(0x1a6)]('selectionMode', selectionMode);

            updateStudentListDisplay();
            loadSettings();
            updateClassSelector();

            alert(_0x4030b8(0x1c6));
        } catch (_0x2a0f83) {
            alert('导入失败：' + _0x2a0f83[_0x4030b8(0x171)]);
            console[_0x4030b8(0x163)]('Import error:', _0x2a0f83);
        }
    };

    _0x43d07a[_0x11abc3(0x1c3)] = function () {
        alert('读取文件失败');
    };

    _0x43d07a[_0x11abc3(0x1fa)](_0x221645);
    _0x51fd69['value'] = '';
}

function showSettings() {
    const _0x14315f = _0x1972c2,
        _0x1a24de = document['getElementById'](_0x14315f(0x1b6));

    _0x1a24de[_0x14315f(0x15c)][_0x14315f(0x166)] = _0x14315f(0x1a9);
}

function closeSettings() {
    const _0x413737 = _0x1972c2,
        _0x2342f1 = document[_0x413737(0x14b)](_0x413737(0x1b6)),
        _0x15f2a2 = document['querySelector'](_0x413737(0x13c))[_0x413737(0x1c8)],
        _0x50127e = document[_0x413737(0x19f)](_0x413737(0x1cd))['checked'];

    _0x15f2a2 !== selectionMode || _0x50127e !== keyboardTriggerEnabled
        ? confirm(_0x413737(0x161)) && (
            _0x2342f1[_0x413737(0x15c)][_0x413737(0x166)] = _0x413737(0x1ea),
            loadSettings()
        )
        : _0x2342f1['style']['display'] = _0x413737(0x1ea);
}

window[_0x1972c2(0x190)] = function (_0x416a8a) {
    const _0xc09d8b = _0x1972c2,
        _0x1d4884 = document[_0xc09d8b(0x14b)](_0xc09d8b(0x1b6));

    _0x416a8a[_0xc09d8b(0x1d7)] == _0x1d4884 && (
        _0x1d4884[_0xc09d8b(0x15c)][_0xc09d8b(0x166)] = _0xc09d8b(0x1ea)
    );
};

document[_0x1972c2(0x1d2)](_0x1972c2(0x153), function (_0x45b2f1) {
    const _0x2080a3 = _0x1972c2;

    if (!keyboardTriggerEnabled) return;

    if (
        _0x45b2f1[_0x2080a3(0x1d7)][_0x2080a3(0x1cb)] === _0x2080a3(0x164) ||
        _0x45b2f1[_0x2080a3(0x1d7)][_0x2080a3(0x1cb)] === _0x2080a3(0x195)
    ) return;

    (
        _0x45b2f1[_0x2080a3(0x182)] === _0x2080a3(0x178) ||
        _0x45b2f1[_0x2080a3(0x182)] === _0x2080a3(0x156) ||
        _0x45b2f1[_0x2080a3(0x182)] === _0x2080a3(0x1fb) ||
        _0x45b2f1[_0x2080a3(0x182)] === ' '
    ) && (
        _0x45b2f1[_0x2080a3(0x1f0)](),
        !isSelecting && startRandomCall()
    );
});

function saveSettings() {
    const _0x406b6c = _0x1972c2,
        _0x28247b = document['querySelectorAll'](_0x406b6c(0x179));

    _0x28247b['forEach'](_0x5cdadd => {
        const _0x52e58a = _0x406b6c;

        _0x5cdadd[_0x52e58a(0x19e)] && (
            selectionMode = _0x5cdadd[_0x52e58a(0x1c8)],
            localStorage[_0x52e58a(0x1a6)](_0x52e58a(0x1f2), selectionMode)
        );
    });

    const _0x49449f = document[_0x406b6c(0x19f)](_0x406b6c(0x1cd));

    _0x49449f && (
        keyboardTriggerEnabled = _0x49449f[_0x406b6c(0x19e)],
        localStorage[_0x406b6c(0x1a6)](_0x406b6c(0x187), keyboardTriggerEnabled)
    );

    updateStudentListDisplay();
    closeSettings();
}
